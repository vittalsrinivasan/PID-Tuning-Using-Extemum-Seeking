clc;
clear all;
close all;
syms s;
num=1;
den=[100000000,80000000,28000000,500000,70000,56000,2800,80,1];
t=0:1:100;
G= tf(num,den);
s=tf('s');

thetha=[0.684 54.9 19.5]';
%G=G*exp(-20*s);
Cr=thetha(1)*(1+1/(thetha(2)*s));
Cy=thetha(1)*(1+1/(thetha(2)*s) + thetha(3)*s);
%fb= feedback(G,Cy);
fb=G/(1+G*Cy);
sys=Cr*fb;
figure
y=step(sys,t);
y=y';
plot(t,y);
p= Cy*G*(1/Cr);
u= feedback(Cr,p);
figure
step(u,t)