function [y,u]= resp(thetha)
syms s;
num=[-5,1];
den=[100000000,80000000,28000000,500000,70000,56000,2800,80,1];
t=0:1:30;
G= tf(num,den);
s=tf('s');

%thetha=[1.33 31 7.74]';
%G=G*exp(-20*s);
Cr=thetha(1)*(1+1/(thetha(2)*s));
Cy=thetha(1)*(1+1/(thetha(2)*s) + thetha(3)*s);
%fb= feedback(G,Cy);
fb=G/(1+G*Cy);
sys=Cr*fb;

y=step(sys,t);


y=y';
%p= Cy*G*(1/Cr);
%u= feedback(Cr,p);
u=1;
end
