
close all;
clear all;
clc;

theta=[3.53 16.8 4.20]';
alpha=[0.05,0.6,0.2]';
gamma=[2000,10000, 2000]';
omega=[0.8*pi,0.8*pi,0.512*pi]';

k = 0:1:30;
N = length(k) ; % no of iterations
theta_hat = zeros(1,length(theta))' ; 
thetahat = [] ;
theta_val=[];
zhi=zeros(1, N);
r=ones(1,N);
j_val=[];
h=0.5;
thetahat=[thetahat theta];
for i = 1:20
    
    [y,u]=resp(theta);
    j=func1(y,r);
    j_val=[j_val j];
    zhi(i+1)= -h*zhi(i) +j;
       
    theta_hat= theta_hat - gamma.*alpha.*(cos(omega.*i)*(j-(1+h)*zhi(i)));
    theta= theta_hat +alpha.*cos(omega.*(i+1));
   
    thetahat=[thetahat theta_hat];
    theta_val=[theta_val theta];
end

figure

k=1:1:30;
k1=0:1:30;
k2=0:1:20;
plot(k2,thetahat);
title("theta")
figure
plot(k,j_val);
title("cost func")
figure
plot(k1,y)
title("output y")
%figure
%step(u,k1);


    