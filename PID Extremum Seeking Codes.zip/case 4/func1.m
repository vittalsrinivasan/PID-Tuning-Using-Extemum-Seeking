function j= func1(y,r)
t0=30;
T=200;
j=(1/(T-t0))*sum((y-r).^2);
end