
close all;
clear all;
clc;

theta=[4.06 9.25 2.31]';
alpha=[0.1, 1, 0.1]';
gamma=[200, 1200, 200]';
omega=[0.8*pi,0.64*pi,0.512*pi]';

k = 0:1:40;
N = length(k) ; % no of iterations
theta_hat = zeros(1,length(theta))' ; 
thetahat = [] ;
theta_val=[];
zhi=zeros(1, N);
r=ones(1,N);
j_val=[];
h=0.5;
thetahat=[thetahat theta];
for i = 1:17
    
    [y,u]=resp(theta);
    j=func1(y,r);
    j_val=[j_val j];
    zhi(i+1)= -h*zhi(i) +j;
       
    theta_hat= theta_hat - gamma.*alpha.*(cos(omega.*i)*(j-(1+h)*zhi(i)));
    theta= theta_hat +alpha.*cos(omega.*(i+1));
   
    thetahat=[thetahat theta_hat];
    theta_val=[theta_val theta];
end

figure

k=1:1:20;
k1=0:1:40;
k2=0:1:20;
subplot(2,2,1)
plot(k,j_val);
title("cost func")
subplot(2,2,2)
plot(k2,thetahat);
title("theta")
subplot(2,2,3)
plot(k1,y)
title("output y")
subplot(2,2,4)
p=step(u,k1);
plot(k1,p)
title("control signal u")

    