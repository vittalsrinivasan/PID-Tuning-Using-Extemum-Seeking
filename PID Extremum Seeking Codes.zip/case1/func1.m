function j= func1(y,r)
t0=10;
T=100;
j=(1/(T-t0))*sum((y-r).^2);
end