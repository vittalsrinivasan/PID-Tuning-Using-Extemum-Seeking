clc;
clear all;
close all;
syms s;
num=1;
den=[20,1];
t=0:1:100;
G= tf(num,den);
s=tf('s');

thetha=[1.33 31 7.74]';
G=G*exp(-20*s);
Cr=thetha(1)*(1+1/(thetha(2)*s));
Cy=thetha(1)*(1+1/(thetha(2)*s) + thetha(3)*s);
%fb= feedback(G,Cy);
fb=G/(1+G*Cy);
sys=Cr*fb;

y=step(sys,t);
y=y';
plot(t,y);
p= Cy*G*(1/Cr);
u= feedback(Cr,p);
