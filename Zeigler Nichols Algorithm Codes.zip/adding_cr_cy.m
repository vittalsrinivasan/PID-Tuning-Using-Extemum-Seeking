clc;
clear all;
close all;

syms s;
num=1;
den=[20,1];
t=0:1:40;
G= tf(num,den);
s=tf('s');

G=G*exp(-5*s);


y=step(G);
%figure
%nyquist(G)
t=0:1:50;
%[Cr,Cy]=zeigler(4.15,9.16,2.29);
[Cr,Cy]=zeigler(2.511,22.5,2.22);

fb=feedback(G,Cy);
sys=Cr*fb;
k=step(sys,t);
subplot(1,2,1)
plot(t,k)
title("Step response for IMC method")
N=length(k);
r=ones(1,N);
p= Cy*G*(1/Cr);
u= feedback(Cr,p);

s=step(u,t);
subplot(1,2,2)
plot(t,s)
title("control signal U for IMC method")
