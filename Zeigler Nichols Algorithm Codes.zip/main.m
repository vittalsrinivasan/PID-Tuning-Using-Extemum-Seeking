clc;
clear all;
close all;

syms s;
num=1;
den=[20,1];
t=0:1:40;
G= tf(num,den);
s=tf('s');

G=G*exp(-5*s);


y=step(G);
figure
nyquist(G)
t=0:1:50;
%Wc=zeigler(4.15,9.16,2.29);
Wc=zeigler(2.511,22.5,2.22);

sys=feedback(series(Wc,G),1);
figure
step(sys,t)

