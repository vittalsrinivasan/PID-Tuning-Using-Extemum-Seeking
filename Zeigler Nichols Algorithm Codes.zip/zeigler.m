function [Cr,Cy]=zeigler(k,ti,td)
s=tf('s');
Cr=k*(1+1/(ti*s));
Cy= k*(1 +(1/(ti*s))+td*s);
end